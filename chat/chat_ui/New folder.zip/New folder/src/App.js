import './App.css';
// import FormIndex from "./modules/authForms";
import FormIndex from './modules/authForms/FormIndex';
// import Input  from './components/Input';

function App() {
  return (
    <>
    <div className="  bg-gradient-to-br from-[#ffe9b0] to-white h-screen flex justify-center items-center">
      <FormIndex/>
    </div>
    
    </>
  );
}

export default App;
